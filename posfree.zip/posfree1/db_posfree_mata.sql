/*
 Navicat Premium Data Transfer

 Source Server         : Mata
 Source Server Type    : MySQL
 Source Server Version : 100316
 Source Host           : localhost:3306
 Source Schema         : db_posfree_mata

 Target Server Type    : MySQL
 Target Server Version : 100316
 File Encoding         : 65001

 Date: 09/04/2020 22:17:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ma_barang
-- ----------------------------
DROP TABLE IF EXISTS `ma_barang`;
CREATE TABLE `ma_barang`  (
  `kd_barang` varchar(5) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nm_barang` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `kd_satuan` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `kd_kategori` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `hrg_jual` int(11) NOT NULL,
  `hrg_beli` int(11) NOT NULL,
  `active` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`kd_barang`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ma_barang
-- ----------------------------
INSERT INTO `ma_barang` VALUES ('00001', 'MARQUISA GK BLACK LABEL 630 ML', 'S00002', 'K00008', 28500, 26000, 'Y');
INSERT INTO `ma_barang` VALUES ('00003', 'ABC SPC GRADE COCOPANDAN', 'S00002', 'K00008', 12900, 11500, 'Y');
INSERT INTO `ma_barang` VALUES ('00004', 'ABC SPC GRADE COCOPANDAN MELON 585 ML', 'S00002', 'K00008', 12900, 11500, 'Y');
INSERT INTO `ma_barang` VALUES ('00005', 'POHON PINANG MARQ SPR 600 ML', 'S00002', 'K00008', 18900, 17500, 'Y');

-- ----------------------------
-- Table structure for ma_kategori_barang
-- ----------------------------
DROP TABLE IF EXISTS `ma_kategori_barang`;
CREATE TABLE `ma_kategori_barang`  (
  `kd_kategori` varchar(6) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nm_kategori` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `active` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`kd_kategori`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ma_kategori_barang
-- ----------------------------
INSERT INTO `ma_kategori_barang` VALUES ('K00001', 'BERAS', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00002', 'MINYAK GORENG', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00003', 'TEPUNG', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00004', 'TELUR', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00005', 'AIR MINERAL', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00006', 'MINUMAN SODA', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00007', 'SUSU', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00008', 'JUICE', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00009', 'MINUMAN ENERY', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00010', 'BISCUIT', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00011', 'WAFER', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00012', 'ROTI TAWAR', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00013', 'ROTI MANIS', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00014', 'SNACK', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00015', 'SABUN MANDI', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00016', 'SHAMPHO', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00017', 'PASTA GIGI', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00018', 'HAND BODY', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00019', 'BAHAN RIAS', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00020', 'DETERJEN', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00021', 'PELEMBUT PAKAIAN', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00022', 'PEWANGI PAKAIAN', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00023', 'SABUN CREAM', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00024', 'SABUN CUCI PIRING', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00025', 'PEMUTIH PAKAIAN', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00026', 'PENGHARUM RUANGAN', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00027', 'PEMBERSIH LANTAI', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00028', 'PEMBERSIH KAMAR MANDI', 'Y');
INSERT INTO `ma_kategori_barang` VALUES ('K00029', 'MAKANAN BEKU', 'T');
INSERT INTO `ma_kategori_barang` VALUES ('K00030', 'OBAT', 'Y');

-- ----------------------------
-- Table structure for ma_satuan_barang
-- ----------------------------
DROP TABLE IF EXISTS `ma_satuan_barang`;
CREATE TABLE `ma_satuan_barang`  (
  `kd_satuan` varchar(6) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nm_satuan` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `active` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`kd_satuan`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ma_satuan_barang
-- ----------------------------
INSERT INTO `ma_satuan_barang` VALUES ('S00001', 'PCS', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00002', 'BOTOL', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00003', 'KALENG', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00004', 'BIJI', 'T');
INSERT INTO `ma_satuan_barang` VALUES ('S00005', 'SACHET', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00006', 'BOX', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00007', 'UNIT', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00008', 'DUS', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00009', 'KOTAK', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00010', 'DRUM', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00011', 'KG', 'Y');
INSERT INTO `ma_satuan_barang` VALUES ('S00012', 'SSS', 'Y');

-- ----------------------------
-- Table structure for ma_supplier
-- ----------------------------
DROP TABLE IF EXISTS `ma_supplier`;
CREATE TABLE `ma_supplier`  (
  `kd_supplier` varchar(7) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nm_supplier` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `almt_supplier` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tlp_supplier` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fax_supplier` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `atas_nama` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `active` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`kd_supplier`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ma_supplier
-- ----------------------------
INSERT INTO `ma_supplier` VALUES ('SUP0001', 'CV.ALAM PERMAI', 'Jl. Residen Abdul Rozak No. 90 Palembang', '0711-123456', '0711-654321', 'ILHAM', '');

-- ----------------------------
-- Table structure for ma_toko
-- ----------------------------
DROP TABLE IF EXISTS `ma_toko`;
CREATE TABLE `ma_toko`  (
  `kd_toko` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nm_toko` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `almt_toko` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `kota` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tlp_toko` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fax_toko` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `logo` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`kd_toko`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ma_toko
-- ----------------------------
INSERT INTO `ma_toko` VALUES ('TK001', 'UD.Matadeveloper', 'Jl.Besar Batang Serangan', 'Medan', '082282845087', '082282845087', 'matadeveloper.png');

-- ----------------------------
-- Table structure for ma_user
-- ----------------------------
DROP TABLE IF EXISTS `ma_user`;
CREATE TABLE `ma_user`  (
  `id_user` varchar(6) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nm_lengkap` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nm_user` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `password` varchar(35) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `akses` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `active` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_user`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ma_user
-- ----------------------------
INSERT INTO `ma_user` VALUES ('UID005', 'Kharisma Maulana Pasaribu', 'maulana', '06b0263db5f7263fb687a977425887b0', 'Kasir', 'Y');
INSERT INTO `ma_user` VALUES ('UID007', 'Superadmin', 'super', '1b3231655cebb7a1f783eddf27d254ca', 'Super', 'Y');
INSERT INTO `ma_user` VALUES ('UID008', 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', 'Y');

-- ----------------------------
-- Table structure for pembelian
-- ----------------------------
DROP TABLE IF EXISTS `pembelian`;
CREATE TABLE `pembelian`  (
  `id` double NOT NULL AUTO_INCREMENT,
  `no_transaksi` double NOT NULL,
  `no_faktur` varchar(16) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `kd_supplier` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tgl_pembelian` date NOT NULL,
  `total_pembelian` int(11) NOT NULL,
  `id_user` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pembelian_detail
-- ----------------------------
DROP TABLE IF EXISTS `pembelian_detail`;
CREATE TABLE `pembelian_detail`  (
  `id` double NOT NULL AUTO_INCREMENT,
  `no_transaksi` double NOT NULL,
  `kd_barang` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `kd_satuan` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `sub_total` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `id`(`id`) USING BTREE,
  INDEX `kd_barang`(`kd_barang`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 91 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pembelian_tmp
-- ----------------------------
DROP TABLE IF EXISTS `pembelian_tmp`;
CREATE TABLE `pembelian_tmp`  (
  `row_id` int(11) NOT NULL,
  `kd_barang` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `kd_satuan` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `user_id` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`row_id`) USING BTREE,
  INDEX `row_id`(`row_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for penjualan
-- ----------------------------
DROP TABLE IF EXISTS `penjualan`;
CREATE TABLE `penjualan`  (
  `id` double NOT NULL AUTO_INCREMENT,
  `no_transaksi` double NOT NULL,
  `no_faktur` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tgl_penjualan` date NOT NULL,
  `total_penjualan` int(11) NOT NULL,
  `user` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `no_faktur`(`no_faktur`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of penjualan
-- ----------------------------
INSERT INTO `penjualan` VALUES (13, 56, '20040900001', '2020-04-09', 28500, 'UID007');

-- ----------------------------
-- Table structure for penjualan_detail
-- ----------------------------
DROP TABLE IF EXISTS `penjualan_detail`;
CREATE TABLE `penjualan_detail`  (
  `id` double NOT NULL AUTO_INCREMENT,
  `no_transaksi` double NOT NULL,
  `kd_barang` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `sub_total` int(11) NOT NULL,
  `hrg_pokok` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 32 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of penjualan_detail
-- ----------------------------
INSERT INTO `penjualan_detail` VALUES (31, 56, '00001', 1, 28500, 28500, 0);

-- ----------------------------
-- Table structure for penjualan_tmp
-- ----------------------------
DROP TABLE IF EXISTS `penjualan_tmp`;
CREATE TABLE `penjualan_tmp`  (
  `id` double NOT NULL,
  `no_faktur` double NOT NULL,
  `kd_barang` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `sub_total` int(11) NOT NULL,
  `hrg_pokok` int(11) NOT NULL,
  `user` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `no_faktur`(`no_faktur`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stock_barang
-- ----------------------------
DROP TABLE IF EXISTS `stock_barang`;
CREATE TABLE `stock_barang`  (
  `id` int(11) NOT NULL,
  `kd_barang` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `hrg_beli_rata2` float NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `kd_barang`(`kd_barang`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for trans_ctr
-- ----------------------------
DROP TABLE IF EXISTS `trans_ctr`;
CREATE TABLE `trans_ctr`  (
  `id` double NOT NULL,
  `counter` double NOT NULL,
  `stat` varchar(3) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `user` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of trans_ctr
-- ----------------------------
INSERT INTO `trans_ctr` VALUES (1, 56, 'O', 'hhalat');

SET FOREIGN_KEY_CHECKS = 1;
