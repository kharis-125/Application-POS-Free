Cara Penggunaan Aplikasi Pos Free Matadeveloper

Copy Folder posfree ke htdocs
 
Install databasenya db_posfree_mata
buat database db_posfree_mata

eksekusi query pada file db_posfree_mata.sql (bisa diimport atau eksekusi query/tab SQL pada phpmyadmin)

Edit koneksi ke database
edit file library/inc.connection.php, sesuaikan nama host, username,password,database 

Untuk Login Username & Password
Type         	Username	Password      
Super 		super  		super
Admin		admin		admin
Kasir		karisma	        liliana15

Anda bisa ganti nama toko sesuai dengan keinginan anda

Terima kasih sudah berkunjung di matadeveloper.com



